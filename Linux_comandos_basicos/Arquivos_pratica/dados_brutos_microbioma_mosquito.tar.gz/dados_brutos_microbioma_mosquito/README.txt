DADOS FICTICIOS PARA FINS DIDATICOS
Disciplina: Introducao a Programacao para Biociencias

Conteudo:
- 40 amostras (mosquito_01 a mosquito_40)
- Sequenciamento paired-end ficticio: R1 e R2
- 12 reads por arquivo
- Reads com 75 nucleotideos
- Qualidades Phred ficticias
